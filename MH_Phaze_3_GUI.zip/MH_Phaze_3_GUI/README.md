# Cardiac Patient Classification — Gradio App

AI-powered heart disease risk assessment using XGBoost.  
**4 conditions · 16 clinical features · 90.0% test accuracy**

## Files

```
cardiac_app/
├── app.py            ← Main Gradio application
├── model.pkl         ← Trained XGBoost classifier
├── scaler.pkl        ← StandardScaler (for continuous features)
├── requirements.txt  ← Python dependencies
└── README.md
```

## Running on Replit

1. Upload this entire folder to a new **Python** Repl.
2. Replit auto-installs from `requirements.txt`.
3. Set the **Run** command to:
   ```
   python app.py
   ```
4. The app will open at the Replit preview URL.

> If scikit-learn version conflicts appear, pin to `scikit-learn==1.5.1` in requirements.txt (already set).

## Tabs

| Tab | Description |
|-----|-------------|
| 🔍 Predict | Enter 9 continuous + 7 categorical values → instant prediction |
| 📊 Models | Full leaderboard, classification report, feature importances, confusion matrix |
| 🗄️ Dataset | Class-wise means, dataset splits, normalised feature profiles |
| ⚗️ Medical Rules | 12 enrichment formulas with medical justification |

## Model pipeline

```
[9 continuous features] → StandardScaler → |
                                            +→ hstack → XGBoost → class probabilities
[7 categorical features] ─────────────────→ |
```

Continuous features (alphabetical, as fitted by scaler):
`age, bmi, bnp, ejection_fraction, fasting_glucose, heart_rate, ldl, spo2, systolic_bp`

Categorical features (raw integer encoding, appended after scaling):
`sob, chest_tightness, smoking, diabetes, edema, palpitations, ecg`
